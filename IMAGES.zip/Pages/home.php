<center><h2>COMPÉTENCES EN PROGRAMMATION</h2></center><BR><BR>


    <center><h2>DÉVELOPPEMENT WEB</h2></center>
    <div class=Stats_languages>
        <div class="circular-progress" 
                data-inner-circle-color="#ebeef3" 
                data-percentage="80" 
                data-progress-color="crimson" 
                data-bg-color="#d9d9d9"
                data-svg="IMAGES/Languages/HTML5_shield.svg">
            <div class="inner-circle"></div>
            <div class="svg-background"></div>
            <p class="percentage">0%</p>
        </div>

        <div class="circular-progress" 
                data-inner-circle-color="#ebeef3" 
                data-percentage="40" 
                data-progress-color="crimson" 
                data-bg-color="#d9d9d9"
                data-svg="IMAGES/Languages/CSS3_shields.svg">
            <div class="inner-circle"></div>
            <div class="svg-background"></div>
            <p class="percentage">0%</p>
        </div>

        <div class="circular-progress" 
                data-inner-circle-color="#ebeef3" 
                data-percentage="55" 
                data-progress-color="crimson" 
                data-bg-color="#d9d9d9"
                data-svg="IMAGES/Languages/JS_shields.svg">
            <div class="inner-circle"></div>
            <div class="svg-background"></div>
            <p class="percentage">0%</p>
        </div>
        
        <div class="circular-progress" 
                data-inner-circle-color="#ebeef3" 
                data-percentage="55" 
                data-progress-color="crimson" 
                data-bg-color="#d9d9d9"
                data-svg="IMAGES/Languages/PHP.svg">
            <div class="inner-circle"></div>
            <div class="svg-background"></div>
            <p class="percentage">0%</p>
        </div>
    </div>


    <br><br><hr class="separator"><br><br>
    <center><h2>DÉVELOPPEMENT JEUX</h2></center>
    <div class=Stats_languages>
        <div class="circular-progress" 
                data-inner-circle-color="#ebeef3" 
                data-percentage="30" 
                data-progress-color="crimson" 
                data-bg-color="#d9d9d9"
                data-svg="IMAGES/Languages/c_plusplus.svg">
            <div class="inner-circle"></div>
            <div class="svg-background"></div>
            <p class="percentage">0%</p>
        </div>

        <div class="circular-progress" 
                data-inner-circle-color="#ebeef3" 
                data-percentage="85" 
                data-progress-color="crimson" 
                data-bg-color="#d9d9d9"
                data-svg="IMAGES/Languages/unreal.svg">
            <div class="inner-circle"></div>
            <div class="svg-background"></div>
            <p class="percentage">0%</p>
        </div>

        <div class="circular-progress" 
                data-inner-circle-color="#ebeef3" 
                data-percentage="45" 
                data-progress-color="crimson" 
                data-bg-color="#d9d9d9"
                data-svg="IMAGES/Languages/Java.svg">
            <div class="inner-circle"></div>
            <div class="svg-background"></div>
            <p class="percentage">0%</p>
        </div>
    </div>

    <br><br><hr class="separator"><br><br>
    <center><h2>DÉVELOPPEMENT AUTRES</h2></center>
    <div class=Stats_languages>
        <div class="circular-progress" 
                data-inner-circle-color="#ebeef3" 
                data-percentage="65" 
                data-progress-color="crimson" 
                data-bg-color="#d9d9d9"
                data-svg="IMAGES/Languages/Python.svg">
            <div class="inner-circle"></div>
            <div class="svg-background"></div>
            <p class="percentage">0%</p>
        </div>

        <div class="circular-progress" 
                data-inner-circle-color="#ebeef3" 
                data-percentage="50" 
                data-progress-color="crimson" 
                data-bg-color="#d9d9d9"
                data-svg="IMAGES/Languages/nodejs-icon.svg">
            <div class="inner-circle"></div>
            <div class="svg-background"></div>
            <p class="percentage">0%</p>
        </div>
    </div>
